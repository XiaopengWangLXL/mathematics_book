# VMLS.jl

Julia package used in the [*Julia Language Companion*](https://web.stanford.edu/~boyd/vmls/vmls-julia-companion.pdf) to the book [*Applied Linear Algebra. Vectors, Matrices, and Least Squares*](https://web.stanford.edu/~boyd/vmls) by Stephen Boyd and Lieven Vandenberghe.
